"""Physical package for Laboratorio de Análisis de Vulnerabilidades.

This package is reserved for module-specific contracts, schemas, panel metadata,
workers, and tool integrations promoted in later controlled rounds.
The module manifest is the source for physical structure validation.
"""
